﻿
EXEC dbo.MakeReservationCorporation '000000000', 1, 5
GO
EXEC dbo.MakeReservationCorporation '000000000', 1, 4
GO
EXEC dbo.MakeReservationCorporation '000000000', 1, 3
GO